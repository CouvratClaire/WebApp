/* global workbox:false */

self.importScripts('docs/4.1/assets/js/vendor/{fileName}')

workbox.precaching.precacheAndRoute([])
