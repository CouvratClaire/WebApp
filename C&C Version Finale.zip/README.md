

###webapp.py

###database.py
COMPETENCE (id, name, description)
EMPLOYEE (id, firstname, lastname, type, nb_mission, wish, project)
PROJECT (id, name, state, description)

###init_db.py 
contains the initialization of the databases in a fixed "beginning" for the tests

###test.db

###static
	##css contains the css files for the layout
	##img contains the images used in the layout
	##js contains the javascript files for the layout
	
	
###templates

attribuer_mission.html.jinja2 displays a form for business engineers so they can choose a study engineer for a mission

clore_mission.html.jinja2 displays a question to confirm closing a mission

employee_form.html.jinja2 displays a form for business engineers to add a new study engineer (firstname, name, 3 competences)

etudes.html.jinja2 displays a table of study engineers for business engineers

index.html.jinja2 displays a dashboard for business engineers

layout.html.jinja2 is the layout used for business engineers

layout2.html.jinja2 is the layout used for study engineers

liste_missions.html.jinja2 displays the list of mission a study engineer is qualified for

login.html.jinja2 displays the fist page where the user gives his id

mauvais_identifiant.html.jinja2 displays an error message when the given id is not correct

mission_form.html.jinja2 displays a form so business engineers can add a new mission (name, description, 2 competences)

missions.html.jinja2 displays a table of missions for business engineers

profile_employee displays.html.jinja2 the profile of a given employee for business engineers

profile_employee2.html.jinja2 displays the own profile of a study engineer

supress_employee.html.jinja2 displays a question to confirm supressing an engineer

supress_mission.html.jinja2 displays a question to confirm supressing a mission

voeux.html.jinja2 dispalys a form for study engineers so they can choose a mission they are qualified for


